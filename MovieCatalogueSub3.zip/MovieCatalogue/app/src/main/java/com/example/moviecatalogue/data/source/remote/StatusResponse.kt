package com.example.moviecatalogue.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}