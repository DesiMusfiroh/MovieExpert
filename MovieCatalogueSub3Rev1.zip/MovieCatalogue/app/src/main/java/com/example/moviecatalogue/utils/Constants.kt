package com.example.moviecatalogue.utils

object Constants {
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "a5856623a69510eec77bfc3bd7116652"
    const val POSTER_URL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2"
    const val BACKDROP_URL = "https://image.tmdb.org/t/p/original"
}